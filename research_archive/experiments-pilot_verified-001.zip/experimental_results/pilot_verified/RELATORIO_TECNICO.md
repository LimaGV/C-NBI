# Relatório técnico — extensão DOE, MaF e ablação CNBI

**Estado: implementação experimental e piloto executados; campanha completa não liberada.**

O piloto revelou falhas metodológicas/operacionais reais; os resultados abaixo não demonstram superioridade de método. Foram preservados dados brutos e por seed, inclusive execuções vazias ou interrompidas.

## 1. Arquivos e reaproveitamento

Criados `cnbi_experiments/{benchmarks,parallel_analysis,doe,solver,comparators,reuse,pilot,analysis,report}.py`, testes, documentação e referências com revisão/hash. Resultados oficiais desta etapa em `experimental_results/pilot_verified/`. A pasta `experimental_results/pilot/` é preliminar e não integra as tabelas deste relatório. Nenhum arquivo do núcleo `cnbi/`, notebook, resultado histórico ou metadado de versão foi alterado.

Reuso direto: base/jacobiana RSM 3D, PA_unc 3D, pesos/ordenação, Pareto/deduplicação. Métricas e Ward são as funções do notebook 04 carregadas por AST sem executar a campanha, com hash em `provenance.json`. Gerador, solver genérico e comparadores são adaptações explícitas; detalhes e diferenças em `cnbi_experiments/README.md`.

## 2. Formulações MaF

MaF8: distância euclidiana aos vértices. MaF9: distância às retas das arestas e exclusão dos polígonos refletidos. Ambos usam D=2 e caixa [-10000,10000]². MaF13 conserva D=5 e os conjuntos de índices publicados; n=D resolve a notação da equação 39. Os objetivos adicionais repetem f1²+f2¹⁰+f3¹⁰ mais a penalidade de ligação. Não é DTLZ7.

Referência/PA MaF8/9: amostra uniforme no polígono. MaF13: octante esférico nas três primeiras coordenadas, invertido para o conjunto Pareto ligado. Na normalização externa MaF13, os objetivos adicionais têm ideal=1/16 e nadir=1. Não se interpreta a imagem completa como esfera M-dimensional.

## 3. Evidência de validação

[Cheng et al.](https://link.springer.com/article/10.1007/s40747-017-0039-7) e [PlatEMO oficial, revisão fixada](https://github.com/BIMK/PlatEMO/tree/d25e65d1ffba58dbf4d7e1b5259786187d12968a/PlatEMO/Problems/Multi-objective%20optimization/MaF). Arquivos MATLAB originais e hashes estão em `cnbi_experiments/references/`. Confronto das equações e testes numéricos independentes passaram; MATLAB/Octave não foi executado.

7 testes da extensão passaram: valores analíticos/escalares, domínio, região proibida, suporte Pareto, Horn sequencial/reprodutível, derivadas/dimensões, orçamento e equivalência da payoff/PA 3D. Os 16 testes do núcleo original passaram. Uma repetição integral do MaF8 spectral com seed 101 reproduziu exatamente os vetores de objetivos e os registros combinatórios: 5.813 avaliações e 132 registros.

## 4. DOE

`doe_design.csv`: 27 condições × 10 seeds = 270 linhas. nx={2,3,5}, delta={1,3,5}, dependência={0,25;0,60;0,85}, tolerância ±0,03. Geometria fixa por condição e observações RSM independentes por seed. O piloto usa seeds 101/102 em três condições; as demais foram planejadas, não calibradas/executadas.

| Condição | Alvo | Obtido |
|---|---:|---:|
| doe_nx2_m4_low | 0.25 | 0.250786 |
| doe_nx3_m7_medium | 0.60 | 0.602044 |
| doe_nx5_m11_high | 0.85 | 0.824150 |

Transição planejada: nx=3, M={3,4,5}, delta={−1,0,1}, dependência média. Não executada nesta etapa. O adaptador rejeita NBI clássico quando M>nx+1.

## 5. Horn por permutação

B=1.000, quantil linear 0,95, permutações independentes por coluna, parada sequencial na primeira falha. Foram salvos os espectros observados, todos os limiares e espectros nulos, amostras X/F e seeds. 24 diagnósticos de sensibilidade, com N=250/500/1000/5000, resultaram todos em posto 2 nos três MaF do piloto.

O posto alimenta uma janela na SVD da payoff; autovalores de correlação não são usados como limiares de valores singulares. RSM continua usando a PA_unc original em 3D e a extensão dimensional da mesma fórmula nos demais nx.

## 6. Ablação

`all` enumera todos os subconjuntos admissíveis; degenerados são registrados sem inventar normal. `spectral` aplica o filtro e usa o mesmo solucionador. Sementes dos resgates são pareadas pelo índice canônico da combinação. k=6 usa resolução experimental explícita 0,5; deltas legados não foram alterados. Não foi criada terceira variante com limiar arbitrário. Execuções truncadas não constituem ablação exaustiva.

## 7. Orçamento

Teto comum: 8.000 avaliações vetoriais por método/caso/seed, incluindo payoff, diferenças finitas, recomposição e amostra usada na PA do método. Custo de referências e sensibilidade externa separado. Gradientes analíticos, tempo e tempo de diagnóstico registrados. Teto igual não significa gasto realizado ou CPU iguais. Maxiter=100 e até dois resgates no piloto, limites explicitamente menores que os padrões 500/8 do núcleo.

EAs usam configuração base anterior, sem alegação de tuning dos novos M. Cardinalidade usa o mínimo dos cinco métodos por cenário/seed e Ward do notebook 04; um método vazio bloqueia a comparação, sem exclusão silenciosa.

## 8. Resultados do piloto

60 execuções = 6 casos × 2 seeds × 5 métodos; 120 linhas incluindo cardinalidade equalizada.

| Caso | Método | Avaliações mín–máx | N não dominados mín–máx | IGD mediana completa (seeds válidas/2) |
|---|---|---:|---:|---:|
| doe_nx2_m4_low | CNBI_all | 2982–5002 | 199–235 | 0.0479328 (2/2) |
| doe_nx2_m4_low | CNBI_spectral | 1806–2982 | 124–235 | 0.0515209 (2/2) |
| doe_nx2_m4_low | VRF-NBI | 672–714 | 44–50 | 0.0838877 (2/2) |
| doe_nx2_m4_low | NSGA-III | 8000–8000 | 9–10 | 0.251597 (2/2) |
| doe_nx2_m4_low | MOEA/D | 8000–8000 | 10–10 | 0.237093 (2/2) |
| doe_nx3_m7_medium | CNBI_all | 8000–8000 | 328–425 | 0.070766 (2/2) |
| doe_nx3_m7_medium | CNBI_spectral | 8000–8000 | 219–425 | 0.071558 (2/2) |
| doe_nx3_m7_medium | VRF-NBI | 878–907 | 28–32 | 0.138299 (2/2) |
| doe_nx3_m7_medium | NSGA-III | 8000–8000 | 26–27 | 0.204475 (2/2) |
| doe_nx3_m7_medium | MOEA/D | 8000–8000 | 28–28 | 0.251417 (2/2) |
| doe_nx5_m11_high | CNBI_all | 8000–8000 | 306–318 | 0.0626102 (2/2) |
| doe_nx5_m11_high | CNBI_spectral | 4081–8000 | 149–315 | 0.0640438 (2/2) |
| doe_nx5_m11_high | VRF-NBI | 332–332 | 7–7 | 0.19676 (2/2) |
| doe_nx5_m11_high | NSGA-III | 8000–8000 | 30–43 | 0.204043 (2/2) |
| doe_nx5_m11_high | MOEA/D | 8000–8000 | 54–60 | 0.234711 (2/2) |
| maf8_m4 | CNBI_all | 8000–8000 | 168–168 | 0.0363113 (2/2) |
| maf8_m4 | CNBI_spectral | 5795–5813 | 102–102 | 0.0459432 (2/2) |
| maf8_m4 | VRF-NBI | 256–256 | 0–0 | indisponível (0/2) |
| maf8_m4 | NSGA-III | 8000–8000 | 10–10 | 0.330547 (2/2) |
| maf8_m4 | MOEA/D | 8000–8000 | 1–1 | 1.97606 (2/2) |
| maf9_m6 | CNBI_all | 8000–8000 | 0–1 | 2840.4 (1/2) |
| maf9_m6 | CNBI_spectral | 7867–8000 | 0–0 | indisponível (0/2) |
| maf9_m6 | VRF-NBI | 2377–4539 | 0–0 | indisponível (0/2) |
| maf9_m6 | NSGA-III | 8000–8000 | 17–20 | 0.41738 (2/2) |
| maf9_m6 | MOEA/D | 8000–8000 | 1–18 | 1.68187 (2/2) |
| maf13_m8 | CNBI_all | 8000–8000 | 0–0 | indisponível (0/2) |
| maf13_m8 | CNBI_spectral | 8000–8000 | 0–0 | indisponível (0/2) |
| maf13_m8 | VRF-NBI | 7934–7934 | 0–0 | indisponível (0/2) |
| maf13_m8 | NSGA-III | 8000–8000 | 36–36 | 0.791009 (2/2) |
| maf13_m8 | MOEA/D | 8000–8000 | 10–17 | 0.850142 (2/2) |

As medianas acima usam somente as seeds disponíveis, identificadas na última coluna. Há frentes vazias e truncamento; não interpretar esses números como ranking científico. `master_results.csv` preserva IGD/HV/GD/Spacing/Sparsity, seeds, contagens e tempos. `paired_ablation.csv` contém diferenças e ganhos relativos pareados; oito figuras estão em `figures/`.

| Caso/seed | Combinações removidas | Variação avaliações | Variação IGD | Variação HV |
|---|---:|---:|---:|---:|
| doe_nx2_m4_low/101 | 20.0% | -63.9% | +13.9% | -1.1% |
| doe_nx2_m4_low/102 | 0.0% | +0.0% | +0.0% | +0.0% |
| doe_nx3_m7_medium/101 | 63.7% | +0.0% | +2.0% | -2.1% |
| doe_nx3_m7_medium/102 | 30.8% | +0.0% | +0.0% | +0.0% |
| doe_nx5_m11_high/101 | 94.6% | +0.0% | -6.5% | +1.5% |
| doe_nx5_m11_high/102 | 98.8% | -49.0% | +11.3% | -3.4% |
| maf8_m4/101 | 30.0% | -27.3% | +26.5% | -2.7% |
| maf8_m4/102 | 30.0% | -27.6% | +26.5% | -2.8% |

Variações = (spectral−all)/all. IGD menor e HV maior são melhores. Os números descrevem o teto piloto; redução de avaliações em braços truncados não mede o custo exaustivo eliminado. Ausência de par válido não é substituída por zero.

## 9. Problemas encontrados e alternativas

1. MaF8 VRF: PCA nos dados uniformes do domínio retorna um fator; não atende 2≤k≤nx+1. Alternativa a decidir: especificar um protocolo de observação apropriado ao VRF, ou reportar sua inaplicabilidade. Não forçar dois fatores nem substituir sua regra de 90%.
2. MaF13 CNBI: 8.000 avaliações terminam na payoff, antes da ablação. Alternativa: novo piloto com teto maior, igual entre métodos; payoff analítica seria outra decisão metodológica, não correção silenciosa.
3. MaF9: o domínio descontínuo e mínimos individuais não únicos dificultam a payoff; há frentes vazias. A adaptação por verificação de factibilidade não equivale à reparação aleatória do PlatEMO no solver. É necessário decidir a política de otimização restrita antes de validar uma campanha.
4. all sob teto fica incompleto em vários casos: não estima todo o custo sem filtro. Planejar uma ablação exaustiva separada ou um protocolo explícito para censura de orçamento.
5. Sensibilidade PA passou, mas cardinalidade falhou nos MaF. Não há inferência fatorial: três condições confundem nx, delta e dependência; o código exige as 27 condições replicadas.
6. A normalização MaF13 foi conferida analiticamente no pós-processamento: ideal adicional=1/16. Nenhum objetivo de otimização foi alterado para esse ajuste externo.

## 10. Custo da campanha e estado final

Tempo somado dos métodos neste piloto: 139.3 s (não inclui preparação, PA de sensibilidade, métricas e gráficos). Uma campanha ainda limitada a 8.000 avaliações teria 1.350 execuções DOE + 650 MaF = 2.000 execuções (assumindo 10 seeds MaF), no máximo 16 milhões de avaliações, excluindo o bloco de transição.

Extrapolação operacional grosseira dos tempos observados por método: 0.76 h; envelope mín–máx observado 0.63–3.96 h. Não é intervalo de confiança nem estimativa de campanha exaustiva: não cobre novos M, calibração de 27 geometrias, tuning, pós-processamento ou maiores tetos necessários. O custo científico completo permanece indeterminado até resolver os bloqueios.

**Campanha completa não executada.** `pilot_status.json` registra `full_campaign_ready=false`. Esta entrega cobre a infraestrutura e o relatório do piloto; não declara cumpridas comparações MaF válidas, transição executada, calibração de todos os cenários ou análise estatística da campanha completa.
