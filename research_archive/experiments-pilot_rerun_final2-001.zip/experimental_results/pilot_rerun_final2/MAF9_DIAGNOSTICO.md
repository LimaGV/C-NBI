# Diagnóstico da falha no MaF9

Este diagnóstico usa as duas seeds do piloto com teto de 50.000 avaliações. O MaF9 é determinístico; as seeds afetam pontos iniciais e algoritmos estocásticos. As duas execuções CNBI reproduziram a mesma payoff e o mesmo padrão inicial de falha.

## O problema tem soluções

MaF9 com M=6 possui duas variáveis e mede a distância a seis retas de um hexágono regular. O interior do hexágono é Pareto ótimo. O PlatEMO também proíbe regiões externas construídas pelas interseções das retas. NSGA-III e MOEA/D devolveram frentes não vazias, portanto a falha observada não significa que o benchmark não tenha soluções.

## CNBI

A payoff 6×6 calculada é:

```text
0.000000  0.000000  0.866025  1.732051  1.732051  0.000000
0.866025  0.000000  0.000000  0.866025  1.732051  0.866025
1.732051  0.866025  0.000000  0.000000  0.866025  1.732051
1.732051  1.732051  0.866025  0.000000  0.000000  1.732051
0.866025  1.732051  1.732051  0.866025  0.000000  0.866025
0.000000  0.866025  1.732051  1.732051  0.866025  0.000000
```

Ela tem posto 3. Isso é compatível com uma imagem gerada por duas variáveis mais o deslocamento afim. O CHIM global tem posto 2 e nulidade 4; por isso NBI direto em seis objetivos não seria admissível, enquanto o CNBI opera com subconjuntos de até três objetivos.

Os objetivos 1 e 6 têm mínimos não únicos: qualquer ponto das respectivas retas tem distância zero. O otimizador escolheu o mesmo vértice compartilhado para ambos. As colunas 1 e 6 da payoff ficaram idênticas. Como consequência, exatamente cinco subconjuntos que contêm simultaneamente esses dois objetivos ficaram degenerados: `(1,6)`, `(1,2,6)`, `(1,3,6)`, `(1,4,6)` e `(1,5,6)` em índices humanos.

Nos subconjuntos não degenerados alcançados antes do teto, apareceram dois tipos de rejeição:

1. o resíduo da igualdade NBI ficou pouco acima da tolerância `1e-5` — mediana aproximada `2,14e-5`, máximo `5,47e-5`;
2. em vários pontos o resíduo era praticamente zero, mas a decisão estava dentro de uma região proibida do MaF9 e foi corretamente rejeitada.

Depois de tentar os pontos iniciais e resgates de cada peso, as duas variantes consumiram o teto nos primeiros subconjuntos. Cada uma produziu três pontos não dominados na avaliação externa, mas não concluiu a enumeração. Derivadas analíticas já foram usadas; portanto o gargalo restante não é o custo de diferenças finitas.

## VRF-NBI

A regra aprovada escolheu três fatores para ultrapassar 90%: os dois primeiros explicam cerca de 74,9%, e os três primeiros praticamente 100%. A payoff fatorial foi:

```text
-1.673366   1.386544  -1.673366
-1.480874  -1.791536  -1.480874
-1.662509   1.420924  -1.662509
```

As colunas 1 e 3 são idênticas. A matriz das diferenças do CHIM tem posto 1 e nulidade 2. O NBI requer nulidade 1 para haver uma normal única. Por isso o resultado correto é `NO_NONDEGENERATE_COMBINATIONS`, antes de resolver subproblemas. Forçar dois fatores violaria a retenção mínima de 90%; escolher arbitrariamente uma das duas normais redefiniria o VRF-NBI.

## Mudanças possíveis

Duas intervenções poderiam ser investigadas, mas afetam a metodologia e não foram aplicadas:

1. definir um desempate geométrico para mínimos não únicos da payoff do MaF9, usando por exemplo o ponto médio de cada aresta como âncora de seu objetivo;
2. incorporar as regiões proibidas como restrições durante a trajetória do solver local, em vez de apenas testar a factibilidade final.

A primeira altera a construção da payoff; a segunda altera o problema passado ao solver NBI. Qualquer uma exige autorização prévia conforme solicitado pelo usuário. A degenerescência do VRF é distinta e não é resolvida automaticamente por essas mudanças.
