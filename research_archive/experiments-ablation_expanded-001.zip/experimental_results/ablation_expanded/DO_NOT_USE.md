# Resultado inválido preservado para auditoria

Esta tentativa repetiu numericamente o cálculo do payoff e não formou pares
comparáveis com a campanha final. A maioria das execuções parou nessa etapa.
Use somente `experimental_results/ablation_expanded_paired`.
