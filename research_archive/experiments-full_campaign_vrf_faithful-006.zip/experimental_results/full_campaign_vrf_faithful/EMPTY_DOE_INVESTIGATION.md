# Investigação das frentes vazias do DOE

## Conclusão

As cinco frentes vazias não foram causadas pelo otimizador NBI, por CHIMs degeneradas ou pela resolução da malha. Todas as combinações foram descartadas pelo filtro espectral antes da resolução dos subproblemas.

Quando `d=1`, a janela produz `ceiling=1`. Isso restringe a seleção, na prática, às combinações com `k=d+1=2`. Porém, o teste também exige `smin > floor`. Para as payoffs 2×2 normalizadas destes casos, o maior `smin` é `sqrt(2)=1,414214`; os pisos globais ficaram entre 1,417122 e 1,580261.

| cenário | seed | d | floor | maior smin de k=2 | selecionadas |
|---|---:|---:|---:|---:|---:|
| doe_nx3_m5_high | 102 | 1 | 1,431643 | 1,414214 | 0 |
| doe_nx3_m5_high | 103 | 1 | 1,417122 | 1,414214 | 0 |
| doe_nx3_m7_high | 105 | 1 | 1,526125 | 1,414214 | 0 |
| doe_nx5_m7_high | 105 | 1 | 1,495838 | 1,414214 | 0 |
| doe_nx5_m7_high | 106 | 1 | 1,580261 | 1,414214 | 0 |

O status `NO_NONDEGENERATE_COMBINATIONS` é impreciso aqui: todas as combinações registradas têm `degenerate=false` e `status=FILTERED`.

## Comparação com o primeiro módulo

A lei de ruído é a mesma: `sigma = sqrt(var(F) * 0.05 / 0.95)`. Ela equivale a desvio-padrão do ruído igual a 22,94% do desvio-padrão do sinal e alvo nominal R²=0,95. Para `nx=3`, também são iguais o CCD, a função de distância quadrática, o ajuste RSM, a normalização da payoff, a PA de incerteza e a regra espectral.

O primeiro módulo contém quatro execuções com `d=1`; seus pisos foram 0,105–0,214 e todas admitiram combinações `k=2`. O caso-limite já existia na regra, mas as geometrias antigas não o acionavam.

O novo gerador diverge em pontos que alteram as âncoras:

1. generaliza `nx=3` para `nx={2,3,5}`;
2. usa amostra radial pseudoaleatória na calibração, enquanto o primeiro usa Sobol;
3. inicia todas as buscas aleatoriamente, enquanto o primeiro começa com três geometrias regulares;
4. usa outra sequência de seeds de calibração;
5. possui uma segunda busca com separação de 5% quando a busca de 10% falha.

## Compactação das âncoras

| geometria | distância mínima | distância mediana | distância máxima |
|---|---:|---:|---:|
| novo nx3,m5,high | 0,288 | 0,575 | 0,988 |
| novo nx3,m7,high | 0,179 | 0,530 | 0,989 |
| novo nx5,m7,high | 0,212 | 0,519 | 0,964 |
| antigo m4,high | 0,168 | 1,306 | 2,445 |
| antigo m6,high | 0,169 | 2,645 | 2,686 |
| antigo m12,high | 0,168 | 2,536 | 2,833 |

O critério controlava correlação média, distância mínima e posto afim, mas não controlava distância mediana, diâmetro ou dispersão global. Nos três novos casos, a primeira inicialização aleatória atingiu a correlação alvo e foi aceita. No primeiro módulo, as três primeiras inicializações eram geometrias regulares, preservando maior dispersão.

## Sensibilidade ao ruído

O arquivo `empty_doe_noise_sensitivity.csv` recalcula somente o diagnóstico com as mesmas âncoras e seeds.

| R² nominal | resultado nas cinco execuções |
|---:|---|
| 0,950 | 5/5 sem combinações |
| 0,975 | 1/5 ainda sem combinações |
| 0,990 | 5/5 selecionam 15–64 combinações |
| 1,000 | 5/5 selecionam 25–119 combinações |

O ruído é um gatilho, mas a compactação das novas âncoras e a comparação entre espectros globais e locais são as causas estruturais.

## Implicação metodológica

A enumeração já inclui `k=d+1=2`; o piso adicional elimina essas combinações. Corrigir o gerador para preservar dispersão ou alterar a janela espectral muda a metodologia experimental e não foi aplicado nesta investigação.
