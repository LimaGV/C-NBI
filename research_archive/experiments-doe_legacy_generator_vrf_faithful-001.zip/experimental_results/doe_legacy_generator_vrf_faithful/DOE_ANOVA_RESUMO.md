# Leitura simples da ANOVA do DOE sintético

## O que foi analisado

A ANOVA usa apenas o CNBI spectral, com comparação em quantidade igual de pontos. Foram usadas as 27 condições sintéticas e as 10 sementes de cada condição. IGD menor é melhor; HV maior é melhor.

## Resultado principal

Não existe um efeito único de dimensão, delta ou dependência que se mantenha igual em todos os casos. A ANOVA encontrou interações: o efeito de um fator muda conforme o valor de outro fator. Por isso, as combinações completas devem ser consideradas na interpretação.

- No IGD, houve evidência de interação entre dimensão e delta. Também houve interação entre dimensão e dependência em parte dos níveis.
- No HV, houve evidência de interação entre dimensão e delta e entre dimensão e dependência.
- O nível de dependência, analisado sozinho, não mostrou diferença clara. Isso não significa que a dependência nunca importa; no IGD e no HV ela aparece em combinação com a dimensão.

## Médias gerais para orientação

Estas médias juntam todas as outras condições e servem apenas para facilitar a leitura:

| Fator | Nível | IGD médio | HV médio |
|---|---:|---:|---:|
| dimensão | 2 | 0,1534 | 0,6826 |
| dimensão | 3 | 0,1603 | 0,5772 |
| dimensão | 5 | 0,1950 | 0,4400 |
| delta | 1 | 0,1534 | 0,7207 |
| delta | 3 | 0,1698 | 0,5414 |
| delta | 5 | 0,1855 | 0,4377 |
| dependência | alta | 0,1476 | 0,5618 |
| dependência | baixa | 0,2115 | 0,5097 |
| dependência | média | 0,1496 | 0,6283 |

Em média, o problema ficou mais difícil quando a dimensão e o delta aumentaram: o IGD subiu e o HV caiu. Como existem interações, essa tendência média não substitui a análise de cada combinação.

## Validade da execução

A campanha terminou com 1.080 de 1.080 execuções, 27 condições, 10 sementes, quatro métodos e nenhuma frente vazia. O maior erro na calibração da dependência foi 0,0366, dentro da tolerância de 0,04. CNBI all não participou do DOE.
