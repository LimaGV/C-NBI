# ANOVA usando m no lugar de delta

No DOE, `m = nx + delta + 1`. Por isso, dimensão e m não formam um fatorial completo: várias combinações não foram executadas. Quando ambos são tratados como fatores categóricos, o modelo cria 72 colunas, mas apenas 36 são independentes. Assim, os efeitos categóricos separados de dimensão, m e suas interações não podem ser estimados de forma única.

Como análise complementar, dimensão e m foram tratados como quantidades numéricas e centralizados. Essa versão tem VIF máximo de 2,21.

| Resposta | R² | R² ajustado | RMSE | F do lack of fit | p do lack of fit |
|---|---:|---:|---:|---:|---:|
| IGD | 84,62% | 83,39% | 0,0212 | 35,00 | < 0,001 |
| HV | 76,43% | 74,54% | 0,1013 | 226,49 | < 0,001 |

No IGD, m, a interação dimensão × m, a interação dimensão × dependência e a interação tripla foram relevantes. No HV, m e dimensão × dependência foram relevantes. O lack of fit permaneceu forte nas duas respostas.

Esta análise numérica exige que o efeito de dimensão e m varie de forma aproximadamente linear. Ela não substitui com vantagem o DOE original com delta: o ajuste do HV caiu bastante e a falta de ajuste continuou significativa.
