# Diagnóstico MaF9 — revisão do otimizador

A falha estava na camada de otimização, não nas equações MaF9, no framework CNBI ou na regra VRF.

A verificação booleana da região proibida ocorria apenas antes e depois do SLSQP. Durante a busca, o solver não recebia uma restrição contínua. Além disso, cada objetivo MaF9 tem uma linha inteira de mínimos; a payoff anterior podia escolher o mesmo ponto para objetivos diferentes e produzir um CHIM artificialmente degenerado.

A revisão fornece ao SLSQP uma margem contínua que representa o mesmo conjunto viável, inicia cada objetivo na aresta correspondente e escolhe de forma determinística um representante entre mínimos equivalentes. No VRF, a restrição e os pontos geométricos são propagados e o Jacobiano dos escores fatoriais usa a regra da cadeia.

Não foram alterados objetivos, região viável, enumeração de subconjuntos, filtro espectral, resolução CNBI, regra VRF max(2,k90) ou orçamento.

## Execuções revisadas

| Seed | Método | Estado | Avaliações | Frente |
|---:|---|---|---:|---:|
| 101 | CNBI_all | COMPLETED | 10994 | 411 |
| 101 | CNBI_spectral | COMPLETED | 4636 | 220 |
| 101 | VRF-NBI | COMPLETED | 4944 | 66 |
| 102 | CNBI_all | COMPLETED | 10994 | 411 |
| 102 | CNBI_spectral | COMPLETED | 4636 | 220 |
| 102 | VRF-NBI | COMPLETED | 4458 | 56 |
