# Substituído pela ablação de nove cenários

Este diretório contém a análise anterior com três cenários. O resultado oficial
atual está em `experimental_results/ablation_expanded_9_final`.
