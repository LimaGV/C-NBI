# Ablação ampliada e pareada

CNBI-all foi executado somente nesta análise. Para que a única diferença fosse o filtro espectral, cada par reutilizou exatamente a mesma matriz payoff e os mesmos ótimos individuais do resultado espectral salvo.

| Cenário | Redução mediana de avaliações | Aumento mediano de IGD | Perda mediana de HV |
|---|---:|---:|---:|
| doe_nx2_m4_low | 16.0% | 0.0034 | 0.0049 |
| doe_nx2_m8_high | 72.6% | 0.0058 | 0.0069 |
| doe_nx5_m7_low | 18.2% | 0.0005 | 0.0013 |

O filtro economizou mais no caso com alta dependência e alto excesso de objetivos. A qualidade caiu pouco, mas CNBI-all foi ligeiramente melhor nos três cenários, como esperado por explorar todas as combinações.

O tempo não é comparado: o braço CNBI-all reutilizou o payoff já calculado. A contagem de avaliações inclui esse custo compartilhado e permanece comparável.
