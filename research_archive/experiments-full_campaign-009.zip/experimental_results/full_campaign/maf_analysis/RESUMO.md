# Análise dos benchmarks MaF

## Base utilizada

Foram avaliadas 13 configurações dos problemas MaF8, MaF9 e MaF13, com 10 sementes e quatro métodos. A comparação principal usa a mesma quantidade de pontos para todos os métodos dentro de cada cenário e semente.

Dos 130 blocos possíveis, 125 permitiram comparação completa. Cinco foram bloqueados porque o VRF-NBI não produziu frente: MaF9 com m=6 na semente 107 e quatro execuções do MaF13. Assim, a análise pareada contém 500 resultados válidos.

## Resultado geral

| Métrica | 1º | 2º | 3º | 4º |
|---|---|---|---|---|
| IGD, menor é melhor | CNBI spectral: 1,46 | MOEA/D: 2,34 | NSGA-III: 2,77 | VRF-NBI: 3,42 |
| HV, maior é melhor | MOEA/D: 1,82 | CNBI spectral: 1,97 | NSGA-III: 2,85 | VRF-NBI: 3,36 |

No IGD, o CNBI spectral foi melhor ou empatou em 85 dos 125 blocos. Ele foi significativamente melhor que cada um dos outros três métodos após a correção para as seis comparações.

No HV, MOEA/D e CNBI spectral ficaram próximos. A diferença entre eles não foi estatisticamente clara (p=0,220). O CNBI foi significativamente melhor que VRF-NBI e NSGA-III.

## Comportamento por família

- MaF8: o CNBI apresentou a melhor posição média no IGD em todas as configurações. No HV, MOEA/D ficou ligeiramente à frente na maior parte dos valores de m.
- MaF9: o CNBI foi o mais estável no IGD. NSGA-III apresentou valores extremos em m=10 e m=15, e VRF-NBI apresentou valores extremos em algumas sementes de m=6 e m=8. No HV, CNBI e MOEA/D ficaram próximos.
- MaF13: CNBI e MOEA/D ficaram próximos nas posições do IGD. O CNBI teve resultados muito ruins nas sementes 102 e 103, embora sua mediana permanecesse competitiva. No HV, MOEA/D ficou ligeiramente à frente em posição média.

## Custo

| Método | Tempo mediano | Avaliações medianas | Pontos medianos da frente completa |
|---|---:|---:|---:|
| VRF-NBI | 2,05 s | 5.143 | 4 |
| CNBI spectral | 2,80 s | 10.531 | 112 |
| NSGA-III | 13,67 s | 50.000 | 36 |
| MOEA/D | 69,11 s | 50.000 | 20 |

O CNBI foi aproximadamente cinco vezes mais rápido que NSGA-III e 25 vezes mais rápido que MOEA/D na mediana, produzindo uma frente completa maior. A comparação de qualidade, entretanto, foi feita após igualar o número de pontos.

## Limitações

Trinta dos 125 blocos válidos foram comparados com apenas um ponto por método; 59 blocos usaram no máximo três pontos. Nesses casos, IGD e principalmente HV medem pouco da cobertura da frente. Portanto, a vantagem do CNBI no IGD é consistente, mas a comparação deve ser repetida com uma cardinalidade mínima maior para sustentar uma conclusão forte sobre diversidade.

Os resultados com a frente completa favorecem o CNBI porque ele gera muito mais pontos. Eles são úteis para avaliar a saída final entregue por cada método, mas não são a comparação mais justa da qualidade de pontos individuais.
