# Arquivo intermediário

Este diretório é uma partição de execução. Os resultados foram consolidados em
`experimental_results/ablation_expanded_9_final`.
