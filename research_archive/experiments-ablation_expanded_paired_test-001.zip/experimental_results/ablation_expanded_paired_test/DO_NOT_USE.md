# Execução de teste

Este diretório contém apenas a semente 101 usada para validar o pareamento.
Use somente `experimental_results/ablation_expanded_paired` para a análise final.
