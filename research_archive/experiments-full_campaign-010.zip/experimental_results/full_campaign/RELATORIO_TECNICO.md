# Relatório técnico — extensão DOE, MaF e ablação CNBI

**Estado: campanha experimental completa executada.**

A campanha preserva falhas metodológicas/operacionais reais; os resultados abaixo não demonstram superioridade de método. Foram preservados dados brutos e por seed, inclusive execuções vazias ou interrompidas.

## 1. Arquivos e reaproveitamento

Criados `cnbi_experiments/{benchmarks,parallel_analysis,doe,solver,comparators,reuse,pilot,analysis,report}.py`, testes, documentação e referências com revisão/hash. Resultados desta revisão em `experimental_results/full_campaign/`. A pasta `experimental_results/pilot/` é preliminar e não integra as tabelas deste relatório. Nenhum arquivo do núcleo `cnbi/`, notebook, resultado histórico ou metadado de versão foi alterado.

Reuso direto: base/jacobiana RSM 3D, PA_unc 3D, pesos/ordenação, Pareto/deduplicação. Métricas e Ward são as funções do notebook 04 carregadas por AST sem executar a campanha, com hash em `provenance.json`. Gerador, solver genérico e comparadores são adaptações explícitas; detalhes e diferenças em `cnbi_experiments/README.md`.

## 2. Formulações MaF

MaF8: distância euclidiana aos vértices. MaF9: distância às retas das arestas e exclusão dos polígonos refletidos. Ambos usam D=2 e caixa [-10000,10000]². MaF13 conserva D=5 e os conjuntos de índices publicados; n=D resolve a notação da equação 39. Os objetivos adicionais repetem f1²+f2¹⁰+f3¹⁰ mais a penalidade de ligação. Não é DTLZ7.

Referência/PA MaF8/9: amostra uniforme no polígono. MaF13: octante esférico nas três primeiras coordenadas, invertido para o conjunto Pareto ligado. Na normalização externa MaF13, os objetivos adicionais têm ideal=1/16 e nadir=1. Não se interpreta a imagem completa como esfera M-dimensional.

## 3. Evidência de validação

[Cheng et al.](https://link.springer.com/article/10.1007/s40747-017-0039-7) e [PlatEMO oficial, revisão fixada](https://github.com/BIMK/PlatEMO/tree/d25e65d1ffba58dbf4d7e1b5259786187d12968a/PlatEMO/Problems/Multi-objective%20optimization/MaF). Arquivos MATLAB originais e hashes estão em `cnbi_experiments/references/`. Confronto das equações e testes numéricos independentes passaram; MATLAB/Octave não foi executado.

11 testes da extensão passaram: regra VRF mínimo 2/90%, regressão MaF9 do payoff/VRF, derivadas analíticas, status de CHIM degenerado, valores analíticos/escalares, domínio, região proibida, suporte Pareto, Horn sequencial/reprodutível, derivadas/dimensões, orçamento e equivalência da payoff/PA 3D. Os 16 testes do núcleo original passaram. A reprodutibilidade determinística é verificada por seed nos testes e novamente na auditoria final dos artefatos.

## 4. DOE

**DOE é somente dos cenários sintéticos e não contém CNBI_all. MaF8/9/13 formam outro bloco.** `CNBI_all` é executado somente em `doe_nx2_m4_low` e aparece apenas em `ablation_results.csv`, ao lado de `CNBI_spectral`. As tabelas `DOE_synthetic_results.csv`, `MaF_benchmarks_results.csv` e `ablation_results.csv` materializam essa separação. A mesma execução CNBI_spectral é reutilizada, sem duplicar cálculo.

`doe_design.csv`: 27 condições × 10 seeds = 270 linhas. nx={2,3,5}, delta={1,3,5}, dependência={0,25;0,60;0,85}, tolerância ±0,03. Geometria fixa por condição e observações RSM independentes por seed. Todas as condições e seeds foram calibradas e executadas.

| Condição | Alvo | Obtido |
|---|---:|---:|
| doe_nx2_m4_low | 0.25 | 0.250786 |
| doe_nx3_m7_medium | 0.60 | 0.602044 |
| doe_nx5_m11_high | 0.85 | 0.824150 |
| doe_nx2_m4_medium | 0.60 | 0.600981 |
| doe_nx2_m4_high | 0.85 | 0.850975 |
| doe_nx2_m6_low | 0.25 | 0.251431 |
| doe_nx2_m6_medium | 0.60 | 0.598664 |
| doe_nx2_m6_high | 0.85 | 0.851187 |
| doe_nx2_m8_low | 0.25 | 0.274807 |
| doe_nx2_m8_medium | 0.60 | 0.598934 |
| doe_nx2_m8_high | 0.85 | 0.836244 |
| doe_nx3_m5_low | 0.25 | 0.249547 |
| doe_nx3_m5_medium | 0.60 | 0.601447 |
| doe_nx3_m5_high | 0.85 | 0.850720 |
| doe_nx3_m7_low | 0.25 | 0.249589 |
| doe_nx3_m7_high | 0.85 | 0.850095 |
| doe_nx3_m9_low | 0.25 | 0.250358 |
| doe_nx3_m9_medium | 0.60 | 0.597593 |
| doe_nx3_m9_high | 0.85 | 0.850175 |
| doe_nx5_m7_low | 0.25 | 0.251362 |
| doe_nx5_m7_medium | 0.60 | 0.599741 |
| doe_nx5_m7_high | 0.85 | 0.846306 |
| doe_nx5_m9_low | 0.25 | 0.251144 |
| doe_nx5_m9_medium | 0.60 | 0.599356 |
| doe_nx5_m9_high | 0.85 | 0.853160 |
| doe_nx5_m11_low | 0.25 | 0.251009 |
| doe_nx5_m11_medium | 0.60 | 0.605044 |

Transição executada: nx=3, M={3,4,5}, delta={−1,0,1}, dependência média. NBI clássico foi executado apenas quando M≤nx+1.

## 5. Horn por permutação

B=1.000, quantil linear 0,95, permutações independentes por coluna, parada sequencial na primeira falha. Foram salvos os espectros observados, todos os limiares e espectros nulos, amostras X/F e seeds. 104 diagnósticos de sensibilidade foram executados com N=250/500/1000/5000; os postos completos estão em `pa_sensitivity.csv`.

O posto alimenta uma janela na SVD da payoff; autovalores de correlação não são usados como limiares de valores singulares. RSM continua usando a PA_unc original em 3D e a extensão dimensional da mesma fórmula nos demais nx.

## 6. Ablação

A ablação usa somente o cenário sintético `doe_nx2_m4_low` (nx=2, M=4, dependência baixa), pois `CNBI_all` concluiu nas duas seeds. Nos demais cenários somente `CNBI_spectral` representa o CNBI.

`all` enumera todos os subconjuntos admissíveis; degenerados são registrados sem inventar normal. `spectral` aplica o filtro e usa o mesmo solucionador. Sementes dos resgates são pareadas pelo índice canônico da combinação. A resolução experimental é Δ₂=0,20, Δ₃=0,20, Δ₄=0,20, Δ₅=0,50 e Δ₆=0,50. O cenário escolhido usa apenas k=2 e k=3, portanto 6 e 21 pesos por subconjunto. Δ₂, Δ₃ e Δ₆ são ajustes experimentais; `cnbi.config.DELTA_BY_K` permanece intacto. Não foi criada terceira variante com limiar arbitrário. Execuções truncadas não constituem ablação exaustiva.

## 7. Orçamento

Teto comum: 50.000 avaliações vetoriais por método/caso/seed, incluindo payoff, diferenças finitas, recomposição e amostra usada na PA do método. Custo de referências e sensibilidade externa separado. Gradientes analíticos, tempo e tempo de diagnóstico registrados. Teto igual não significa gasto realizado ou CPU iguais. Maxiter=100 e até dois resgates no piloto, limites explicitamente menores que os padrões 500/8 do núcleo.

EAs usam configuração base anterior, sem alegação de tuning dos novos M. Cardinalidade usa o mínimo dos métodos presentes por cenário/seed e Ward do notebook 04; um método vazio bloqueia a comparação, sem exclusão silenciosa.

## 8. Resultados do piloto

1610 execuções em 40 casos e 10 seeds; 3220 linhas incluindo cardinalidade equalizada.

| Caso | Método | Avaliações mín–máx | N não dominados mín–máx | IGD mediana completa (seeds válidas/10) |
|---|---|---:|---:|---:|
| doe_nx2_m4_low | CNBI_all | 1075–6639 | 59–98 | 0.0783612 (10/10) |
| doe_nx2_m4_low | CNBI_spectral | 677–2173 | 48–83 | 0.0783612 (10/10) |
| doe_nx2_m4_low | VRF-NBI | 256–273 | 16–20 | 0.14694 (10/10) |
| doe_nx2_m4_low | NSGA-III | 50000–50000 | 9–10 | 0.255155 (10/10) |
| doe_nx2_m4_low | MOEA/D | 50000–50000 | 10–10 | 0.250279 (10/10) |
| doe_nx3_m7_medium | CNBI_spectral | 4063–22778 | 172–659 | 0.0580424 (10/10) |
| doe_nx3_m7_medium | VRF-NBI | 136–484 | 5–14 | 0.214474 (10/10) |
| doe_nx3_m7_medium | NSGA-III | 50000–50000 | 22–28 | 0.210376 (10/10) |
| doe_nx3_m7_medium | MOEA/D | 50000–50000 | 28–28 | 0.257953 (10/10) |
| doe_nx5_m11_high | CNBI_spectral | 2650–19545 | 67–493 | 0.0766613 (10/10) |
| doe_nx5_m11_high | VRF-NBI | 240–279 | 4–5 | 0.276197 (10/10) |
| doe_nx5_m11_high | NSGA-III | 50000–50000 | 26–57 | 0.168054 (10/10) |
| doe_nx5_m11_high | MOEA/D | 50000–50000 | 62–66 | 0.206792 (10/10) |
| maf8_m4 | CNBI_spectral | 2675–2862 | 38–38 | 0.0779879 (10/10) |
| maf8_m4 | VRF-NBI | 1890–6573 | 1–4 | 0.378666 (10/10) |
| maf8_m4 | NSGA-III | 50000–50000 | 9–10 | 0.257144 (10/10) |
| maf8_m4 | MOEA/D | 50000–50000 | 10–10 | 0.199863 (10/10) |
| maf9_m6 | CNBI_spectral | 2996–2996 | 91–91 | 0.0929915 (10/10) |
| maf9_m6 | VRF-NBI | 2564–5563 | 0–20 | 1.10064 (9/10) |
| maf9_m6 | NSGA-III | 50000–50000 | 15–21 | 0.47957 (10/10) |
| maf9_m6 | MOEA/D | 50000–50000 | 15–21 | 0.202133 (10/10) |
| maf13_m8 | CNBI_spectral | 19948–24989 | 17–19 | 0.395887 (10/10) |
| maf13_m8 | VRF-NBI | 1855–28432 | 0–11 | 1.57786 (8/10) |
| maf13_m8 | NSGA-III | 50000–50000 | 33–36 | 0.753997 (10/10) |
| maf13_m8 | MOEA/D | 50000–50000 | 11–21 | 0.795141 (10/10) |
| doe_nx2_m4_medium | CNBI_spectral | 350–922 | 22–51 | 0.0674302 (10/10) |
| doe_nx2_m4_medium | VRF-NBI | 98–112 | 6–6 | 0.112754 (10/10) |
| doe_nx2_m4_medium | NSGA-III | 50000–50000 | 8–10 | 0.158816 (10/10) |
| doe_nx2_m4_medium | MOEA/D | 50000–50000 | 10–10 | 0.163616 (10/10) |
| doe_nx2_m4_high | CNBI_spectral | 279–15618 | 15–47 | 0.0545407 (10/10) |
| doe_nx2_m4_high | VRF-NBI | 99–109 | 6–6 | 0.139022 (10/10) |
| doe_nx2_m4_high | NSGA-III | 50000–50000 | 8–10 | 0.16061 (10/10) |
| doe_nx2_m4_high | MOEA/D | 50000–50000 | 10–10 | 0.179242 (10/10) |
| doe_nx2_m6_low | CNBI_spectral | 1354–5246 | 123–248 | 0.0629332 (10/10) |
| doe_nx2_m6_low | VRF-NBI | 247–266 | 17–20 | 0.187889 (10/10) |
| doe_nx2_m6_low | NSGA-III | 50000–50000 | 19–21 | 0.261528 (10/10) |
| doe_nx2_m6_low | MOEA/D | 50000–50000 | 21–21 | 0.389967 (10/10) |
| doe_nx2_m6_medium | CNBI_spectral | 738–13473 | 38–161 | 0.0457873 (10/10) |
| doe_nx2_m6_medium | VRF-NBI | 100–108 | 5–6 | 0.12898 (10/10) |
| doe_nx2_m6_medium | NSGA-III | 50000–50000 | 13–21 | 0.160803 (10/10) |
| doe_nx2_m6_medium | MOEA/D | 50000–50000 | 21–21 | 0.271096 (10/10) |
| doe_nx2_m6_high | CNBI_spectral | 561–2656 | 32–48 | 0.037539 (10/10) |
| doe_nx2_m6_high | VRF-NBI | 98–108 | 6–6 | 0.172878 (10/10) |
| doe_nx2_m6_high | NSGA-III | 50000–50000 | 12–21 | 0.166048 (10/10) |
| doe_nx2_m6_high | MOEA/D | 50000–50000 | 21–21 | 0.370564 (10/10) |
| doe_nx2_m8_low | CNBI_spectral | 3468–16739 | 324–477 | 0.0469931 (10/10) |
| doe_nx2_m8_low | VRF-NBI | 253–272 | 18–20 | 0.18874 (10/10) |
| doe_nx2_m8_low | NSGA-III | 50000–50000 | 34–36 | 0.203753 (10/10) |
| doe_nx2_m8_low | MOEA/D | 50000–50000 | 35–36 | 0.460255 (10/10) |
| doe_nx2_m8_medium | CNBI_spectral | 4822–31664 | 178–408 | 0.0415617 (10/10) |
| doe_nx2_m8_medium | VRF-NBI | 98–108 | 6–6 | 0.167187 (10/10) |
| doe_nx2_m8_medium | NSGA-III | 50000–50000 | 31–36 | 0.145121 (10/10) |
| doe_nx2_m8_medium | MOEA/D | 50000–50000 | 35–36 | 0.43748 (10/10) |
| doe_nx2_m8_high | CNBI_spectral | 1084–32515 | 69–119 | 0.0332512 (10/10) |
| doe_nx2_m8_high | VRF-NBI | 100–109 | 6–6 | 0.194925 (10/10) |
| doe_nx2_m8_high | NSGA-III | 50000–50000 | 26–35 | 0.211485 (10/10) |
| doe_nx2_m8_high | MOEA/D | 50000–50000 | 34–36 | 0.588727 (10/10) |
| doe_nx3_m5_low | CNBI_spectral | 1797–8126 | 107–376 | 0.0880635 (10/10) |
| doe_nx3_m5_low | VRF-NBI | 358–766 | 15–51 | 0.188616 (10/10) |
| doe_nx3_m5_low | NSGA-III | 50000–50000 | 14–15 | 0.234576 (10/10) |
| doe_nx3_m5_low | MOEA/D | 50000–50000 | 15–15 | 0.258657 (10/10) |
| doe_nx3_m5_medium | CNBI_spectral | 568–16850 | 28–126 | 0.0571489 (10/10) |
| doe_nx3_m5_medium | VRF-NBI | 124–359 | 6–15 | 0.115982 (10/10) |
| doe_nx3_m5_medium | NSGA-III | 50000–50000 | 10–15 | 0.177715 (10/10) |
| doe_nx3_m5_medium | MOEA/D | 50000–50000 | 15–15 | 0.207325 (10/10) |
| doe_nx3_m5_high | CNBI_spectral | 275–1308 | 0–65 | 0.110077 (8/10) |
| doe_nx3_m5_high | VRF-NBI | 151–198 | 3–4 | 0.254174 (10/10) |
| doe_nx3_m5_high | NSGA-III | 50000–50000 | 10–15 | 0.169524 (10/10) |
| doe_nx3_m5_high | MOEA/D | 50000–50000 | 14–15 | 0.17176 (10/10) |
| doe_nx3_m7_low | VRF-NBI | 723–1244 | 36–46 | 0.202787 (10/10) |
| doe_nx3_m7_low | CNBI_spectral | 13343–23446 | 570–1068 | 0.0689465 (10/10) |
| doe_nx3_m7_low | NSGA-III | 50000–50000 | 21–28 | 0.25704 (10/10) |
| doe_nx3_m7_low | MOEA/D | 50000–50000 | 28–28 | 0.36423 (10/10) |
| doe_nx3_m7_high | VRF-NBI | 164–180 | 2–4 | 0.363942 (10/10) |
| doe_nx3_m7_high | CNBI_spectral | 419–2782 | 0–85 | 0.168621 (9/10) |
| doe_nx3_m7_high | NSGA-III | 50000–50000 | 13–28 | 0.203741 (10/10) |
| doe_nx3_m7_high | MOEA/D | 50000–50000 | 26–28 | 0.275477 (10/10) |
| doe_nx3_m9_low | VRF-NBI | 735–752 | 34–49 | 0.274628 (10/10) |
| doe_nx3_m9_low | CNBI_spectral | 23628–39565 | 1318–2702 | 0.0641382 (10/10) |
| doe_nx3_m9_low | NSGA-III | 50000–50000 | 41–45 | 0.28517 (10/10) |
| doe_nx3_m9_low | MOEA/D | 50000–50000 | 45–45 | 0.477006 (10/10) |
| doe_nx3_m9_medium | CNBI_spectral | 8365–50000 | 381–2183 | 0.0395647 (10/10) |
| doe_nx3_m9_medium | VRF-NBI | 353–376 | 14–20 | 0.182805 (10/10) |
| doe_nx3_m9_medium | NSGA-III | 50000–50000 | 31–45 | 0.189405 (10/10) |
| doe_nx3_m9_medium | MOEA/D | 50000–50000 | 44–45 | 0.309446 (10/10) |
| doe_nx3_m9_high | VRF-NBI | 125–147 | 6–6 | 0.0967124 (10/10) |
| doe_nx3_m9_high | CNBI_spectral | 2551–7630 | 53–117 | 0.0250881 (10/10) |
| doe_nx3_m9_high | NSGA-III | 50000–50000 | 17–41 | 0.0697692 (10/10) |
| doe_nx3_m9_high | MOEA/D | 50000–50000 | 43–45 | 0.176203 (10/10) |
| doe_nx5_m7_low | VRF-NBI | 1120–1181 | 27–38 | 0.218092 (10/10) |
| doe_nx5_m7_low | CNBI_spectral | 14189–42919 | 595–1666 | 0.0904586 (10/10) |
| doe_nx5_m7_low | NSGA-III | 50000–50000 | 24–28 | 0.220846 (10/10) |
| doe_nx5_m7_low | MOEA/D | 50000–50000 | 28–28 | 0.224119 (10/10) |
| doe_nx5_m7_medium | VRF-NBI | 214–248 | 6–6 | 0.13524 (10/10) |
| doe_nx5_m7_medium | CNBI_spectral | 10695–50000 | 207–670 | 0.0380096 (10/10) |
| doe_nx5_m7_medium | NSGA-III | 50000–50000 | 25–28 | 0.131069 (10/10) |
| doe_nx5_m7_medium | MOEA/D | 50000–50000 | 28–28 | 0.169653 (10/10) |
| doe_nx5_m7_high | CNBI_spectral | 913–1144 | 0–17 | 0.180769 (8/10) |
| doe_nx5_m7_high | VRF-NBI | 260–301 | 2–3 | 0.285487 (10/10) |
| doe_nx5_m7_high | NSGA-III | 50000–50000 | 18–28 | 0.162263 (10/10) |
| doe_nx5_m7_high | MOEA/D | 50000–50000 | 28–28 | 0.155769 (10/10) |
| doe_nx5_m9_low | VRF-NBI | 701–1137 | 13–50 | 0.321955 (10/10) |
| doe_nx5_m9_low | CNBI_spectral | 50000–50000 | 1727–2377 | 0.089414 (10/10) |
| doe_nx5_m9_low | NSGA-III | 50000–50000 | 33–45 | 0.250345 (10/10) |
| doe_nx5_m9_low | MOEA/D | 50000–50000 | 43–45 | 0.292241 (10/10) |
| doe_nx5_m9_medium | VRF-NBI | 213–232 | 6–6 | 0.147887 (10/10) |
| doe_nx5_m9_medium | CNBI_spectral | 42826–50000 | 511–631 | 0.0265382 (10/10) |
| doe_nx5_m9_medium | NSGA-III | 50000–50000 | 36–45 | 0.177532 (10/10) |
| doe_nx5_m9_medium | MOEA/D | 50000–50000 | 44–45 | 0.214814 (10/10) |
| doe_nx5_m9_high | VRF-NBI | 205–233 | 6–6 | 0.0954224 (10/10) |
| doe_nx5_m9_high | CNBI_spectral | 1786–33232 | 46–336 | 0.0363274 (10/10) |
| doe_nx5_m9_high | NSGA-III | 50000–50000 | 36–45 | 0.0718864 (10/10) |
| doe_nx5_m9_high | MOEA/D | 50000–50000 | 44–45 | 0.143739 (10/10) |
| doe_nx5_m11_low | VRF-NBI | 713–744 | 11–13 | 0.720005 (10/10) |
| doe_nx5_m11_low | CNBI_spectral | 50000–50000 | 2362–2860 | 0.107216 (10/10) |
| doe_nx5_m11_low | NSGA-III | 50000–50000 | 54–66 | 0.285981 (10/10) |
| doe_nx5_m11_low | MOEA/D | 50000–50000 | 63–66 | 0.331467 (10/10) |
| doe_nx5_m11_medium | VRF-NBI | 532–595 | 12–17 | 0.148318 (10/10) |
| doe_nx5_m11_medium | CNBI_spectral | 10575–22252 | 207–451 | 0.0523963 (10/10) |
| doe_nx5_m11_medium | NSGA-III | 50000–50000 | 46–62 | 0.125812 (10/10) |
| doe_nx5_m11_medium | MOEA/D | 50000–50000 | 50–66 | 0.148574 (10/10) |
| maf8_m6 | CNBI_spectral | 4106–4324 | 112–112 | 0.0685426 (10/10) |
| maf8_m6 | VRF-NBI | 1244–10050 | 1–4 | 0.611454 (10/10) |
| maf8_m6 | NSGA-III | 50000–50000 | 20–21 | 0.228314 (10/10) |
| maf8_m6 | MOEA/D | 50000–50000 | 20–21 | 0.327735 (10/10) |
| maf8_m8 | CNBI_spectral | 7302–7597 | 212–212 | 0.0646834 (10/10) |
| maf8_m8 | VRF-NBI | 1397–9276 | 1–6 | 0.617228 (10/10) |
| maf8_m8 | NSGA-III | 50000–50000 | 35–36 | 0.265902 (10/10) |
| maf8_m8 | MOEA/D | 50000–50000 | 32–36 | 0.516075 (10/10) |
| maf8_m10 | CNBI_spectral | 10351–10781 | 325–325 | 0.0574205 (10/10) |
| maf8_m10 | VRF-NBI | 1429–5932 | 1–6 | 0.643162 (10/10) |
| maf8_m10 | NSGA-III | 50000–50000 | 54–55 | 0.270004 (10/10) |
| maf8_m10 | MOEA/D | 50000–50000 | 1–55 | 0.609792 (10/10) |
| maf8_m15 | VRF-NBI | 2123–21296 | 1–5 | 0.897182 (10/10) |
| maf8_m15 | CNBI_spectral | 20007–20564 | 489–489 | 0.0595997 (10/10) |
| maf8_m15 | NSGA-III | 50000–50000 | 119–120 | 0.236709 (10/10) |
| maf8_m15 | MOEA/D | 50000–50000 | 1–117 | 0.848325 (10/10) |
| maf9_m4 | CNBI_spectral | 1944–1944 | 36–36 | 0.128808 (10/10) |
| maf9_m4 | VRF-NBI | 1413–15736 | 1–6 | 1.08627 (10/10) |
| maf9_m4 | NSGA-III | 50000–50000 | 10–10 | 0.493417 (10/10) |
| maf9_m4 | MOEA/D | 50000–50000 | 9–10 | 0.226292 (10/10) |
| maf9_m8 | CNBI_spectral | 7557–7557 | 158–158 | 0.100276 (10/10) |
| maf9_m8 | VRF-NBI | 2686–7140 | 3–21 | 1.19949 (10/10) |
| maf9_m8 | NSGA-III | 50000–50000 | 35–36 | 1.54325 (10/10) |
| maf9_m8 | MOEA/D | 50000–50000 | 2–34 | 0.290956 (10/10) |
| maf9_m10 | CNBI_spectral | 17752–17752 | 293–293 | 0.0805319 (10/10) |
| maf9_m10 | VRF-NBI | 26276–49987 | 1–9 | 1.31671 (10/10) |
| maf9_m10 | NSGA-III | 50000–50000 | 39–51 | 0.638079 (10/10) |
| maf9_m10 | MOEA/D | 50000–50000 | 4–54 | 0.4281 (10/10) |
| maf9_m15 | VRF-NBI | 5600–49995 | 1–14 | 1.26311 (10/10) |
| maf9_m15 | CNBI_spectral | 44886–44886 | 745–745 | 0.0698668 (10/10) |
| maf9_m15 | NSGA-III | 50000–50000 | 120–120 | 0.873542 (10/10) |
| maf13_m10 | CNBI_spectral | 26522–33585 | 17–19 | 0.424899 (10/10) |
| maf13_m10 | VRF-NBI | 1158–47131 | 0–11 | 1.75399 (9/10) |
| maf13_m10 | NSGA-III | 50000–50000 | 50–55 | 0.760439 (10/10) |
| maf13_m10 | MOEA/D | 50000–50000 | 11–22 | 0.81388 (10/10) |
| maf9_m15 | MOEA/D | 50000–50000 | 1–116 | 0.819395 (10/10) |
| maf13_m15 | CNBI_spectral | 43594–50000 | 17–19 | 0.476682 (10/10) |
| maf13_m15 | VRF-NBI | 1187–42150 | 0–11 | 2.12306 (9/10) |
| maf13_m15 | NSGA-III | 50000–50000 | 114–120 | 0.73514 (10/10) |
| maf13_m15 | MOEA/D | 50000–50000 | 8–22 | 1.12997 (10/10) |

As medianas acima usam somente as seeds disponíveis, identificadas na última coluna. Há frentes vazias e truncamento; não interpretar esses números como ranking científico. `master_results.csv` preserva IGD/HV/GD/Spacing/Sparsity, seeds, contagens e tempos. `paired_ablation.csv` contém diferenças e ganhos relativos pareados; oito figuras estão em `figures/`.

| Caso/seed | Combinações removidas | Variação avaliações | Variação IGD | Variação HV |
|---|---:|---:|---:|---:|
| doe_nx2_m4_low/101 | 20.0% | -88.9% | +15.4% | -2.6% |
| doe_nx2_m4_low/102 | 0.0% | +0.0% | +0.0% | +0.0% |
| doe_nx2_m4_low/103 | 30.0% | -37.5% | +2.6% | -0.5% |
| doe_nx2_m4_low/104 | 20.0% | -33.4% | +11.4% | -0.9% |
| doe_nx2_m4_low/105 | 0.0% | +0.0% | +0.0% | +0.0% |
| doe_nx2_m4_low/106 | 10.0% | -16.4% | +0.3% | -0.0% |
| doe_nx2_m4_low/107 | 0.0% | +0.0% | +0.0% | +0.0% |
| doe_nx2_m4_low/108 | 10.0% | -15.8% | +2.0% | -0.2% |
| doe_nx2_m4_low/109 | 10.0% | -59.6% | +2.2% | -0.2% |
| doe_nx2_m4_low/110 | 0.0% | +0.0% | +0.0% | +0.0% |

Variações = (spectral−all)/all. IGD menor e HV maior são melhores. Os números descrevem o teto piloto; redução de avaliações em braços truncados não mede o custo exaustivo eliminado. Ausência de par válido não é substituída por zero.

## 9. Problemas encontrados e alternativas

1. VRF atualizado por solicitação do usuário: k=max(2,k90), mantendo pelo menos 90% de variância acumulada. A quantidade escolhida e a retenção real estão nos diagnósticos. O limite dimensional continua sendo verificado.
2. MaF13: as derivadas analíticas e os pontos iniciais geométricos reduziram a payoff para cerca de 2.300 avaliações. Com teto comum de 50.000, CNBI_spectral completou as seeds executadas e produziu frentes não vazias.
3. MaF9 CNBI: a falha estava na adaptação numérica do otimizador. As restrições eram verificadas somente depois da otimização e a payoff escolhia o mesmo representante para mínimos não únicos. Uma margem contínua equivalente à região viável, pontos iniciais por aresta e desempate determinístico produziram seis representantes distintos. CNBI_spectral passou a concluir bem abaixo do teto, sem alterar equações, filtro ou enumeração CNBI.
4. MaF9 VRF: o colapso anterior dos fatores também era numérico. Ao propagar a mesma restrição, usar pontos iniciais geométricos e aplicar a regra da cadeia ao Jacobiano dos escores, a payoff fatorial tornou-se não degenerada e as seeds executadas concluíram. Permanecem três fatores, pois dois retêm apenas cerca de 75%.
5. CNBI_all: foi limitado à ablação em `doe_nx2_m4_low`. As 10 seeds concluíram a enumeração, permitindo comparar o filtro com uma referência all não truncada.
6. Cardinalidade: comparar frentes com o mesmo número de soluções só funciona quando todos os métodos devolvem alguma solução. Uma frente vazia impede essa comparação nesse benchmark/seed. A ANOVA usa somente os 27 cenários sintéticos com blocos por seed.
7. A normalização MaF13 foi conferida analiticamente no pós-processamento: ideal adicional=1/16. É apenas a escala comum usada para calcular as métricas, não uma falha do benchmark. Nenhum objetivo de otimização foi alterado para esse ajuste externo.

Na revisão VRF, a biblioteca também emitiu avisos de matriz singular no cálculo dos pesos dos scores e utilizou seu fallback para cargas fatoriais. Isso merece diagnóstico antes de interpretar cientificamente esses casos; não foi criada uma nova regra de regularização.

## 10. Custo da campanha e estado final

Tempo somado dos métodos nesta campanha: 143230.9 s (não inclui preparação, PA de sensibilidade, métricas e gráficos). Uma campanha limitada a 50.000 avaliações teria 1.090 execuções DOE (incluindo 10 de ablação) + 520 MaF = 1.610 execuções, no máximo 80.500.000 avaliações, excluindo o bloco de transição.

Extrapolação operacional grosseira dos tempos observados por método: 4.83 h; envelope mín–máx observado 3.55–1077.90 h. Não é intervalo de confiança nem estimativa de campanha exaustiva: não cobre novos M, calibração de 27 geometrias, tuning, pós-processamento ou maiores tetos necessários. O custo científico completo permanece indeterminado até resolver os bloqueios.

**Campanha completa executada.** `campaign_status.json` registra a cobertura final.
