# Relatório técnico — extensão DOE, MaF e ablação CNBI

**Estado: implementação experimental e piloto executados; campanha completa não liberada.**

O piloto revelou falhas metodológicas/operacionais reais; os resultados abaixo não demonstram superioridade de método. Foram preservados dados brutos e por seed, inclusive execuções vazias ou interrompidas.

## 1. Arquivos e reaproveitamento

Criados `cnbi_experiments/{benchmarks,parallel_analysis,doe,solver,comparators,reuse,pilot,analysis,report}.py`, testes, documentação e referências com revisão/hash. Resultados desta revisão em `experimental_results/pilot_single_ablation/`. A pasta `experimental_results/pilot/` é preliminar e não integra as tabelas deste relatório. Nenhum arquivo do núcleo `cnbi/`, notebook, resultado histórico ou metadado de versão foi alterado.

Reuso direto: base/jacobiana RSM 3D, PA_unc 3D, pesos/ordenação, Pareto/deduplicação. Métricas e Ward são as funções do notebook 04 carregadas por AST sem executar a campanha, com hash em `provenance.json`. Gerador, solver genérico e comparadores são adaptações explícitas; detalhes e diferenças em `cnbi_experiments/README.md`.

## 2. Formulações MaF

MaF8: distância euclidiana aos vértices. MaF9: distância às retas das arestas e exclusão dos polígonos refletidos. Ambos usam D=2 e caixa [-10000,10000]². MaF13 conserva D=5 e os conjuntos de índices publicados; n=D resolve a notação da equação 39. Os objetivos adicionais repetem f1²+f2¹⁰+f3¹⁰ mais a penalidade de ligação. Não é DTLZ7.

Referência/PA MaF8/9: amostra uniforme no polígono. MaF13: octante esférico nas três primeiras coordenadas, invertido para o conjunto Pareto ligado. Na normalização externa MaF13, os objetivos adicionais têm ideal=1/16 e nadir=1. Não se interpreta a imagem completa como esfera M-dimensional.

## 3. Evidência de validação

[Cheng et al.](https://link.springer.com/article/10.1007/s40747-017-0039-7) e [PlatEMO oficial, revisão fixada](https://github.com/BIMK/PlatEMO/tree/d25e65d1ffba58dbf4d7e1b5259786187d12968a/PlatEMO/Problems/Multi-objective%20optimization/MaF). Arquivos MATLAB originais e hashes estão em `cnbi_experiments/references/`. Confronto das equações e testes numéricos independentes passaram; MATLAB/Octave não foi executado.

11 testes da extensão passaram: regra VRF mínimo 2/90%, regressão MaF9 do payoff/VRF, derivadas analíticas, status de CHIM degenerado, valores analíticos/escalares, domínio, região proibida, suporte Pareto, Horn sequencial/reprodutível, derivadas/dimensões, orçamento e equivalência da payoff/PA 3D. Os 16 testes do núcleo original passaram. A reprodutibilidade determinística é verificada por seed nos testes e novamente na auditoria final dos artefatos.

## 4. DOE

**DOE é somente dos cenários sintéticos e não contém CNBI_all. MaF8/9/13 formam outro bloco.** `CNBI_all` é executado somente em `doe_nx2_m4_low` e aparece apenas em `ablation_results.csv`, ao lado de `CNBI_spectral`. As tabelas `DOE_synthetic_results.csv`, `MaF_benchmarks_results.csv` e `ablation_results.csv` materializam essa separação. A mesma execução CNBI_spectral é reutilizada, sem duplicar cálculo.

`doe_design.csv`: 27 condições × 10 seeds = 270 linhas. nx={2,3,5}, delta={1,3,5}, dependência={0,25;0,60;0,85}, tolerância ±0,03. Geometria fixa por condição e observações RSM independentes por seed. O piloto usa seeds 101/102 em três condições; as demais foram planejadas, não calibradas/executadas.

| Condição | Alvo | Obtido |
|---|---:|---:|
| doe_nx2_m4_low | 0.25 | 0.250786 |
| doe_nx3_m7_medium | 0.60 | 0.602044 |
| doe_nx5_m11_high | 0.85 | 0.824150 |

Transição planejada: nx=3, M={3,4,5}, delta={−1,0,1}, dependência média. Não executada nesta etapa. O adaptador rejeita NBI clássico quando M>nx+1.

## 5. Horn por permutação

B=1.000, quantil linear 0,95, permutações independentes por coluna, parada sequencial na primeira falha. Foram salvos os espectros observados, todos os limiares e espectros nulos, amostras X/F e seeds. 24 diagnósticos de sensibilidade, com N=250/500/1000/5000, resultaram todos em posto 2 nos três MaF do piloto.

O posto alimenta uma janela na SVD da payoff; autovalores de correlação não são usados como limiares de valores singulares. RSM continua usando a PA_unc original em 3D e a extensão dimensional da mesma fórmula nos demais nx.

## 6. Ablação

A ablação usa somente o cenário sintético `doe_nx2_m4_low` (nx=2, M=4, dependência baixa), pois `CNBI_all` concluiu nas duas seeds. Nos demais cenários somente `CNBI_spectral` representa o CNBI.

`all` enumera todos os subconjuntos admissíveis; degenerados são registrados sem inventar normal. `spectral` aplica o filtro e usa o mesmo solucionador. Sementes dos resgates são pareadas pelo índice canônico da combinação. A resolução é Δ₂=0,10, Δ₃=0,10, Δ₄=0,20, Δ₅=0,50 e Δ₆=0,50. O cenário escolhido usa apenas k=2 e k=3, portanto 11 e 66 pesos por subconjunto. Δ₆ é uma extensão experimental; os deltas legados não foram alterados. Não foi criada terceira variante com limiar arbitrário. Execuções truncadas não constituem ablação exaustiva.

## 7. Orçamento

Teto comum: 50.000 avaliações vetoriais por método/caso/seed, incluindo payoff, diferenças finitas, recomposição e amostra usada na PA do método. Custo de referências e sensibilidade externa separado. Gradientes analíticos, tempo e tempo de diagnóstico registrados. Teto igual não significa gasto realizado ou CPU iguais. Maxiter=100 e até dois resgates no piloto, limites explicitamente menores que os padrões 500/8 do núcleo.

EAs usam configuração base anterior, sem alegação de tuning dos novos M. Cardinalidade usa o mínimo dos métodos presentes por cenário/seed e Ward do notebook 04; um método vazio bloqueia a comparação, sem exclusão silenciosa.

## 8. Resultados do piloto

50 execuções em 6 casos e 2 seeds; 100 linhas incluindo cardinalidade equalizada.

| Caso | Método | Avaliações mín–máx | N não dominados mín–máx | IGD mediana completa (seeds válidas/2) |
|---|---|---:|---:|---:|
| doe_nx2_m4_low | CNBI_all | 2982–5002 | 199–235 | 0.0479328 (2/2) |
| doe_nx2_m4_low | CNBI_spectral | 1806–2982 | 124–235 | 0.0515209 (2/2) |
| doe_nx2_m4_low | VRF-NBI | 672–714 | 44–50 | 0.0838877 (2/2) |
| doe_nx2_m4_low | NSGA-III | 50000–50000 | 9–10 | 0.253622 (2/2) |
| doe_nx2_m4_low | MOEA/D | 50000–50000 | 10–10 | 0.23646 (2/2) |
| doe_nx3_m7_medium | CNBI_spectral | 15028–30330 | 391–1343 | 0.0545394 (2/2) |
| doe_nx3_m7_medium | VRF-NBI | 878–907 | 28–32 | 0.138299 (2/2) |
| doe_nx3_m7_medium | NSGA-III | 50000–50000 | 22–26 | 0.215326 (2/2) |
| doe_nx3_m7_medium | MOEA/D | 50000–50000 | 28–28 | 0.246403 (2/2) |
| doe_nx5_m11_high | CNBI_spectral | 4081–47769 | 149–1245 | 0.0544325 (2/2) |
| doe_nx5_m11_high | VRF-NBI | 332–332 | 7–7 | 0.19676 (2/2) |
| doe_nx5_m11_high | NSGA-III | 50000–50000 | 31–37 | 0.242285 (2/2) |
| doe_nx5_m11_high | MOEA/D | 50000–50000 | 66–66 | 0.202282 (2/2) |
| maf8_m4 | CNBI_spectral | 3347–3390 | 102–102 | 0.0459432 (2/2) |
| maf8_m4 | VRF-NBI | 5222–20350 | 1–7 | 0.537994 (2/2) |
| maf8_m4 | NSGA-III | 50000–50000 | 10–10 | 0.246429 (2/2) |
| maf8_m4 | MOEA/D | 50000–50000 | 10–10 | 0.203395 (2/2) |
| maf9_m6 | CNBI_spectral | 4636–4636 | 220–220 | 0.0641459 (2/2) |
| maf9_m6 | VRF-NBI | 4458–4944 | 56–66 | 0.877116 (2/2) |
| maf9_m6 | NSGA-III | 50000–50000 | 18–18 | 0.6584 (2/2) |
| maf9_m6 | MOEA/D | 50000–50000 | 21–21 | 0.201137 (2/2) |
| maf13_m8 | CNBI_spectral | 39424–40622 | 25–28 | 0.251167 (2/2) |
| maf13_m8 | VRF-NBI | 22180–49948 | 3–10 | 1.55426 (2/2) |
| maf13_m8 | NSGA-III | 50000–50000 | 33–35 | 0.881728 (2/2) |
| maf13_m8 | MOEA/D | 50000–50000 | 19–21 | 0.759933 (2/2) |

As medianas acima usam somente as seeds disponíveis, identificadas na última coluna. Há frentes vazias e truncamento; não interpretar esses números como ranking científico. `master_results.csv` preserva IGD/HV/GD/Spacing/Sparsity, seeds, contagens e tempos. `paired_ablation.csv` contém diferenças e ganhos relativos pareados; oito figuras estão em `figures/`.

| Caso/seed | Combinações removidas | Variação avaliações | Variação IGD | Variação HV |
|---|---:|---:|---:|---:|
| doe_nx2_m4_low/101 | 20.0% | -63.9% | +13.9% | -1.1% |
| doe_nx2_m4_low/102 | 0.0% | +0.0% | +0.0% | +0.0% |

Variações = (spectral−all)/all. IGD menor e HV maior são melhores. Os números descrevem o teto piloto; redução de avaliações em braços truncados não mede o custo exaustivo eliminado. Ausência de par válido não é substituída por zero.

## 9. Problemas encontrados e alternativas

1. VRF atualizado por solicitação do usuário: k=max(2,k90), mantendo pelo menos 90% de variância acumulada. A quantidade escolhida e a retenção real estão nos diagnósticos. O limite dimensional continua sendo verificado.
2. MaF13: as derivadas analíticas e os pontos iniciais geométricos reduziram a payoff para cerca de 2.300 avaliações. Com teto comum de 50.000, CNBI_spectral completou nas duas seeds e produziu frentes não vazias.
3. MaF9 CNBI: a falha estava na adaptação numérica do otimizador. As restrições eram verificadas somente depois da otimização e a payoff escolhia o mesmo representante para mínimos não únicos. Uma margem contínua equivalente à região viável, pontos iniciais por aresta e desempate determinístico produziram seis representantes distintos. CNBI_spectral passou a concluir bem abaixo do teto, sem alterar equações, filtro ou enumeração CNBI.
4. MaF9 VRF: o colapso anterior dos fatores também era numérico. Ao propagar a mesma restrição, usar pontos iniciais geométricos e aplicar a regra da cadeia ao Jacobiano dos escores, a payoff fatorial tornou-se não degenerada e as duas seeds concluíram. Permanecem três fatores, pois dois retêm apenas cerca de 75%.
5. CNBI_all: foi limitado à ablação em `doe_nx2_m4_low`. As duas seeds concluíram a enumeração, permitindo comparar o filtro com uma referência all não truncada.
6. Cardinalidade: comparar frentes com o mesmo número de soluções só funciona quando todos os métodos devolvem alguma solução. Uma frente vazia impede essa comparação nesse benchmark/seed. Separadamente, a ANOVA é somente dos sintéticos: foram executadas três das 27 condições, insuficientes para separar estatisticamente os efeitos de nx, delta e dependência.
7. A normalização MaF13 foi conferida analiticamente no pós-processamento: ideal adicional=1/16. É apenas a escala comum usada para calcular as métricas, não uma falha do benchmark. Nenhum objetivo de otimização foi alterado para esse ajuste externo.

Na revisão VRF, a biblioteca também emitiu avisos de matriz singular no cálculo dos pesos dos scores e utilizou seu fallback para cargas fatoriais. Isso merece diagnóstico antes de interpretar cientificamente esses casos; não foi criada uma nova regra de regularização.

## 10. Custo da campanha e estado final

Tempo somado dos métodos neste piloto: 815.7 s (não inclui preparação, PA de sensibilidade, métricas e gráficos). Uma campanha limitada a 50.000 avaliações teria 1.090 execuções DOE (incluindo 10 de ablação) + 520 MaF = 1.610 execuções, no máximo 80.500.000 avaliações, excluindo o bloco de transição.

Extrapolação operacional grosseira dos tempos observados por método: 4.53 h; envelope mín–máx observado 3.57–23.56 h. Não é intervalo de confiança nem estimativa de campanha exaustiva: não cobre novos M, calibração de 27 geometrias, tuning, pós-processamento ou maiores tetos necessários. O custo científico completo permanece indeterminado até resolver os bloqueios.

**Campanha completa não executada.** `pilot_status.json` registra `full_campaign_ready=false`. Esta entrega cobre a infraestrutura e o relatório do piloto; não declara cumpridas comparações MaF válidas, transição executada, calibração de todos os cenários ou análise estatística da campanha completa.
