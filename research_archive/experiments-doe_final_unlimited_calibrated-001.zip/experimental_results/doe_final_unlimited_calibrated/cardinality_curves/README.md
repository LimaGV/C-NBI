# Curvas de qualidade por quantidade de pontos

As frentes completas continuam sendo o resultado principal. Estas curvas são
uma análise de sensibilidade. Em cada quantidade, um bloco cenário/semente só
entra quando os quatro métodos possuem pontos suficientes. A redução usa o
mesmo agrupamento hierárquico da análise de cardinalidade já existente.

Os gráficos por cenário mostram os valores reais de IGD e HV. O gráfico
agregado usa a razão para o melhor método dentro do mesmo bloco, pois não é
correto tirar a média direta de HV entre problemas com números diferentes de
objetivos. Razão 1 indica o melhor resultado naquele bloco.
