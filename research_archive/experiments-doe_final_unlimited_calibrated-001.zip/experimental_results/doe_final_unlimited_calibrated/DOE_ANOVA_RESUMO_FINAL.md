# Resultados finais do DOE sintético

## Validade da campanha

A campanha contém 27 cenários, 10 sementes e quatro métodos, totalizando 1.080 execuções. Todas terminaram e nenhuma produziu frente vazia. O CNBI e o VRF foram executados sem teto de avaliações. As EAs usaram limites finitos definidos pelo número de objetivos e parâmetros escolhidos pela calibração.

## ANOVA do CNBI

O modelo principal usa dimensão, delta, dependência, todas as interações até a interação tripla e um bloco para a semente. Para IGD, R² ajustado = 0.8826; para HV, R² ajustado = 0.9700.

A interação tripla acrescenta 8 graus de liberdade. Comparada ao modelo com interações apenas duplas, ela tem p = 7.668e-27 para IGD e p = 1.786e-72 para HV. Valores pequenos indicam que o efeito conjunto dos três fatores não deve ser ignorado.

Com a interação tripla, o modelo representa separadamente a média de cada uma das 27 combinações. Por isso, não sobra uma diferença entre o modelo e as médias das células para testar como falta de ajuste. A falta de ajuste do modelo triplo é, portanto, não testável; os resíduos restantes medem a variação entre sementes dentro de cada cenário. No modelo com interações duplas, o teste acima mede exatamente a parte omitida pela interação tripla.

O maior VIF foi 1.000. O cálculo usa contrastes ortogonais adequados ao DOE balanceado; assim, a interação tripla não criou colinearidade problemática.

Os gráficos de resíduos mostram alguns valores extremos e desvio da normalidade. Por isso, também foi aplicada uma correção robusta a variâncias diferentes e valores extremos. Todos os termos experimentais permaneceram significativos; o maior p robusto entre eles foi 1.526e-09. Os tamanhos dos efeitos e os gráficos devem receber mais atenção que p-valores extremamente pequenos.

## Comparação entre métodos

Para evitar que cenários com escalas diferentes dominem a média, as 10 sementes foram resumidas pela mediana dentro de cada cenário. Depois, cada método recebeu uma nota de 0 a 1 em cada um dos 27 cenários, combinando IGD e HV. O maior valor médio foi de **CNBI_spectral**, com 0.785. Esta é uma síntese descritiva; as tabelas preservam IGD e HV separadamente.

O teste global entre métodos encontrou diferenças para IGD (p = 5.15e-09) e HV (p = 0.002017). As comparações par a par usam correção de Holm e também tratam os 27 cenários, não as 270 execuções, como unidades independentes.

## Arquivos

- `anova_final/delta_model_summary.csv`: R², R² ajustado, erro médio e teste da interação tripla.
- `anova_final/delta_triple_VIF.csv`: VIF de todos os coeficientes.
- `anova_final/IGD_triple_anova.csv` e `HV_triple_anova.csv`: testes dos termos no DOE em blocos, usando a variação entre sementes dentro de cada cenário.
- `anova_final/IGD_triple_terms_HC3.csv` e `HV_triple_terms_HC3.csv`: checagem robusta dos mesmos termos.
- `anova_final/factor_means.csv`: médias de IGD e HV em cada nível.
- `method_paired_summary.csv`: comparação dos quatro métodos em condições iguais.
- `method_friedman.csv` e `method_pairwise_wilcoxon.csv`: testes entre métodos usando os 27 cenários como blocos.
- `budget_summary.csv`: avaliações usadas e política de orçamento.
