# MaF13: escala e soluções extremas

Os valores atuais de IGD, GD e HV já usam a faixa teórica da fronteira real para normalizar cada objetivo. Por isso, recalcular essa normalização reproduz os valores atuais; o GD alto não é causado pela falta de escala.

| M | IGD normalizado | GD normalizado | Distância mediana dos pontos | Distância p95 | Fração de pontos com distância > 1 |
|---:|---:|---:|---:|---:|---:|
| 8 | 0.3959 | 1.68e+06 | 0.0654 | 5.84e+06 | 36.1% |
| 10 | 0.4249 | 1.99e+06 | 0.0706 | 6.9e+06 | 36.1% |
| 15 | 0.4767 | 2.6e+06 | 0.0757 | 9.04e+06 | 36.1% |

A distância mediana é pequena, mas a cauda é extrema. Assim, a maioria mais próxima descreve razoavelmente a fronteira enquanto um grupo de soluções muito afastadas eleva fortemente o GD médio. O artigo deve mostrar IGD, GD e os quantis de distância em conjunto.
