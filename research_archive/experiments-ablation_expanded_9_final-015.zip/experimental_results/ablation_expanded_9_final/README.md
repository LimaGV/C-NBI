# Ablação ampliada e pareada

CNBI-all foi executado somente nesta análise. Para que a única diferença fosse o filtro espectral, cada par reutilizou exatamente a mesma matriz payoff e os mesmos ótimos individuais do resultado espectral salvo. Os nove cenários formam um subconjunto balanceado: cada nível de dimensão, excesso de objetivos e dependência aparece três vezes.

| Cenário | Redução mediana de avaliações | Aumento mediano de IGD | Perda mediana de HV |
|---|---:|---:|---:|
| doe_nx2_m4_low | 16.0% | 0.0034 | 0.0049 |
| doe_nx2_m6_medium | 25.7% | 0.0053 | 0.0051 |
| doe_nx2_m8_high | 72.6% | 0.0058 | 0.0069 |
| doe_nx3_m5_high | 94.7% | 0.0032 | 0.0053 |
| doe_nx3_m7_low | 46.1% | 0.0056 | 0.0096 |
| doe_nx3_m9_medium | 70.5% | 0.0067 | 0.0072 |
| doe_nx5_m7_medium | 96.7% | 0.0049 | 0.0111 |
| doe_nx5_m9_high | 99.1% | 0.0133 | 0.0232 |
| doe_nx5_m11_low | 63.8% | 0.0037 | 0.0056 |

A economia variou bastante entre as nove estruturas. O maior ganho ocorreu quando o filtro reteve uma parcela pequena das combinações. A qualidade caiu pouco na maior parte dos casos, enquanto CNBI-all foi ligeiramente melhor por explorar todas as combinações.

O tempo não é comparado: o braço CNBI-all reutilizou o payoff já calculado. A contagem de avaliações inclui esse custo compartilhado e permanece comparável.
