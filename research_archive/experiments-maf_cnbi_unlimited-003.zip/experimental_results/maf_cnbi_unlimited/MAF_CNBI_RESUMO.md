# Benchmark MaF somente com CNBI

Foram executadas 13 configurações, com 10 sementes cada. As 130 execuções terminaram sem teto de avaliações e sem frentes vazias. Este benchmark é separado do DOE sintético e não participa da ANOVA nem da comparação entre métodos.

No MaF8, o IGD mediano variou de 0.0574 a 0.0780. No MaF9, variou de 0.0699 a 0.1288. O desenho no espaço x mostra cobertura progressivamente mais densa quando M aumenta.

O MaF13 é mais difícil para o CNBI: o IGD mediano foi 0.3959, 0.4249 e 0.4767. A comparação visual também revela pontos do CNBI muito afastados da fronteira real, principalmente nas soluções extremas. Por isso, o GD é muito alto e deve ser apresentado junto com o IGD; o IGD sozinho não evidencia esses pontos afastados.

A quantidade final pequena não veio de falta de tentativas. Em M=15, a mediana foi de 224 soluções aceitas pelos subproblemas, 30 decisões distintas após remover repetições e 18 pontos finais após remover dominadas.

Os valores de HV entre números diferentes de objetivos não devem ser comparados diretamente, porque a dimensão do volume muda. Eles são adequados para comparar resultados dentro da mesma configuração.
