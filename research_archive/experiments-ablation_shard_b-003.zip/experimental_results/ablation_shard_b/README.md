# Ablação ampliada e pareada

CNBI-all foi executado somente nesta análise. Para que a única diferença fosse o filtro espectral, cada par reutilizou exatamente a mesma matriz payoff e os mesmos ótimos individuais do resultado espectral salvo.

| Cenário | Redução mediana de avaliações | Aumento mediano de IGD | Perda mediana de HV |
|---|---:|---:|---:|
| doe_nx5_m11_low | 66.3% | 0.0039 | 0.0052 |

O filtro economizou mais no caso com alta dependência e alto excesso de objetivos. A qualidade caiu pouco, mas CNBI-all foi ligeiramente melhor nos três cenários, como esperado por explorar todas as combinações.

O tempo não é comparado: o braço CNBI-all reutilizou o payoff já calculado. A contagem de avaliações inclui esse custo compartilhado e permanece comparável.
