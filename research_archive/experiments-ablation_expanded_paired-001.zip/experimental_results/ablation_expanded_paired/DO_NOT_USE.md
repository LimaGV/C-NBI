# Ambiente diferente da campanha

Esta execução pareada foi feita com Python 3.14 e SciPy 1.17. Os resultados são
quase idênticos, mas a análise oficial deve usar
`experimental_results/ablation_expanded_final`, executada no mesmo ambiente da
campanha (Python 3.10 e SciPy 1.14.1).
