# Diagnóstico MaF9 — resolução de 20%

A correção do adaptador do otimizador permanece válida. Nesta revisão, CNBI_spectral e VRF-NBI foram reexecutados com Δ₂=Δ₃=0,20; CNBI_all não integra o benchmark MaF.

| Seed | Método | Estado | Avaliações | Frente |
|---:|---|---|---:|---:|
| 101 | CNBI_spectral | COMPLETED | 2996 | 91 |
| 101 | VRF-NBI | COMPLETED | 4620 | 15 |
| 102 | CNBI_spectral | COMPLETED | 2996 | 91 |
| 102 | VRF-NBI | COMPLETED | 2605 | 20 |
